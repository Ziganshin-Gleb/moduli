from function import b as a, q as r
from function import b1, q1 as r1
from function import *
from function import (e, q, b, b1, q1)
import function as m

m.e()
a()
r()
b1()
q1()