def e():
    print("Hello1")

def q():
    print("Hello2")


def b():
    print("Hello2")


def b1():
    print("Hello3")


def q1():
    print("Hello3")
