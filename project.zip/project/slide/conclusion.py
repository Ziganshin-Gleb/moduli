import function

function.time()
function.random()