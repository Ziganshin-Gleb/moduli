def time():
    print(f'time: {5556665.454554}')


def random():
    print(f'random: {0.87654679876543457}')