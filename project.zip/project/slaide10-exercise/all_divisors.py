def b():
    s = int(input("Введите число: "))
    for i in range(1, s):
        if s % i == 0:
            print(i, end=" ")