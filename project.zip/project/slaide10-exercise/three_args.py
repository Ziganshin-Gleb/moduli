def a():
    h = input("Введите значение: ")
    b = input("Введите значение: ")
    if h == "None" or b == "None":
        return 'None'
    elif int(h) and int(b):
       return f"var1 = {h}, Var2 = {b}"
    else:
        pass