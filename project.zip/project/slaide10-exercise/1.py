from all_divisors import b as e

e()