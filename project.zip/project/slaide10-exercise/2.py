from three_args import a as b

print(b())
