def check():
    a = input("Введите Палиндром: ")
    b = a[::-1]
    if a == b:
        return "Является"
    else:
        return "Данное слово неПалиндром"
