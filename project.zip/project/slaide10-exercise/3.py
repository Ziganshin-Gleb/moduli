import exercise_3
print(exercise_3.check())
