import exercise_4

exercise_4.f()
