def f():
    text = input("ВВедите текст: ")
    words = text.split()
    longest = max(words, key=len)
    print(longest)